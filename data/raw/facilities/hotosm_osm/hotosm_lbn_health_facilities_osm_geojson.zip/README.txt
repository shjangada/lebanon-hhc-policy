oex export
==========

Generated:        2026-11-16 02:06:43 UTC
oex version:      0.4.30
Project:          https://github.com/osgeonepal/oex

Country (ISO3):   LBN
Boundary:         geoBoundaries gbOpen ADM0 (buffered +10000m, simplified 1000m)
Bounding box:     (35.0013, 32.9617, 36.7275, 34.7836)

Dataset:          health_facilities
Format:           GeoJSON (geojson)
Features:         1,392

Source:           OpenStreetMap contributors
Source URL:       https://www.openstreetmap.org/
Snapshot:         2026-11-15
License:          Open Database License (ODC-ODbL)
License URL:      https://opendatacommons.org/licenses/odbl/1-0/

About the source
  OpenStreetMap is a community-edited geographic dataset of the world. Country
  features are extracted from the source PBF via quackosm with the union of
  all category tag filters; per-category exports apply tag predicates at query
  time.

Notes
  - GeoJSON is a single-file text format. Consider gpkg for very large layers.

Feedback:         https://github.com/osgeonepal/oex/issues
Engine: geofabrik